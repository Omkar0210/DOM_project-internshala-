// Add student functionality
function addStudent() {
    const name = document.getElementById('studentName').value;
    const Class = document.getElementById('studentClass').value;
    const id = document.getElementById('studentID').value;
    const email = document.getElementById('emailID').value;
    const address = document.getElementById('studentAddress').value;
    const contact = document.getElementById('contactNo').value;

    if (!name || !Class || !id || !email || !address || !contact) {
        alert('Please fill in all fields.');
        return;
    }

    if (!/^[a-zA-Z ]+$/.test(name)) {
        alert('Student name must contain only characters.');
        return;
    }

    if (!/^[0-9]+$/.test(contact)) {
        alert('Contact number must contain only numbers.');
        return;
    }

    const table = document.getElementById('studentTable');
    const row = table.insertRow();

    row.innerHTML = `
        <td>${name}</td>
        <td>${Class}</td>
        <td>${id}</td>
        <td>${email}</td>
        <td>${address}</td>
        <td>${contact}</td>
        <td>
            <button onclick="editStudent(this)">Edit</button>
            <button onclick="deleteStudent(this)">Delete</button>
        </td>
    `;

    saveToLocalStorage();
}

function editStudent(button) {
    const row = button.parentElement.parentElement;
    const cells = row.getElementsByTagName('td');
    document.getElementById('studentName').value = cells[0].textContent;
    document.getElementById('studentClass').value = cells[1].textContent;
    document.getElementById('studentID').value = cells[2].textContent;
    document.getElementById('emailID').value = cells[3].textContent;
    document.getElementById('studentAddress').value = cells[4].textContent;
    document.getElementById('contactNo').value = cells[5].textContent;
    row.remove();
    saveToLocalStorage();
}

function deleteStudent(button) {
    button.parentElement.parentElement.remove();
    saveToLocalStorage();
}

function saveToLocalStorage() {
    const rows = document.getElementById('studentTable').rows;
    const students = [];

    for (let i = 0; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        students.push({
            name: cells[0].textContent,
            class: cells[1].textContent,
            id: cells[2].textContent,
            email: cells[3].textContent,
            address: cells[4].textContent,
            contact: cells[5].textContent,
        });
    }

    localStorage.setItem('students', JSON.stringify(students));
}

function loadFromLocalStorage() {
    const students = JSON.parse(localStorage.getItem('students')) || [];
    const table = document.getElementById('studentTable');

    students.forEach(student => {
        const row = table.insertRow();
        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.class}</td>
            <td>${student.id}</td>
            <td>${student.email}</td>
            <td>${student.address}</td>
            <td>${student.contact}</td>
            <td>
                <button onclick="editStudent(this)">Edit</button>
                <button onclick="deleteStudent(this)">Delete</button>
            </td>
        `;
    });
}

document.addEventListener('DOMContentLoaded', loadFromLocalStorage);
